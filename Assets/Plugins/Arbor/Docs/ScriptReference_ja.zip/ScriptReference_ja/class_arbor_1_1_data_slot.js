var class_arbor_1_1_data_slot =
[
    [ "Disconnect", "class_arbor_1_1_data_slot.html#a5cecb0c0e26d5a3cde95c24c7c47ece9", null ],
    [ "nodeGraph", "class_arbor_1_1_data_slot.html#a0329858672ae3b819a15c60d0a04d012", null ],
    [ "position", "class_arbor_1_1_data_slot.html#aa7851f9da6d3bee9317d22c7bf3cda4d", null ],
    [ "dataType", "class_arbor_1_1_data_slot.html#aff6db2c0dc2932b8752201f03fea9d2b", null ],
    [ "slotType", "class_arbor_1_1_data_slot.html#a1ea575cdeeacc228952dd85dbe696f1c", null ]
];