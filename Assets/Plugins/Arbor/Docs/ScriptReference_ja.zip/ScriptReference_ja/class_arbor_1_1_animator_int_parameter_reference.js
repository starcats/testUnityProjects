var class_arbor_1_1_animator_int_parameter_reference =
[
    [ "Get", "class_arbor_1_1_animator_int_parameter_reference.html#a6f81c8f05fd6884b9fbbaab400152e5c", null ],
    [ "Set", "class_arbor_1_1_animator_int_parameter_reference.html#a8ed097593986737546a55270b67ad52a", null ]
];