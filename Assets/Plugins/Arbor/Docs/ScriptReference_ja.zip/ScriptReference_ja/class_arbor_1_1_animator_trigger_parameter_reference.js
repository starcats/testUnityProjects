var class_arbor_1_1_animator_trigger_parameter_reference =
[
    [ "Reset", "class_arbor_1_1_animator_trigger_parameter_reference.html#a372de693ad40b3f42839c8ec6ac845f4", null ],
    [ "Set", "class_arbor_1_1_animator_trigger_parameter_reference.html#a614cfe7992438ee53cfd9440848c39e7", null ]
];