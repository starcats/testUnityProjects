var class_arbor_1_1_group_node =
[
    [ "AutoAlignment", "class_arbor_1_1_group_node.html#aa182c9e607d1ca657b868fd8adfbda6a", [
      [ "None", "class_arbor_1_1_group_node.html#aa182c9e607d1ca657b868fd8adfbda6aa6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Vertical", "class_arbor_1_1_group_node.html#aa182c9e607d1ca657b868fd8adfbda6aa06ce2a25e5d12c166a36f654dbea6012", null ],
      [ "Horizonal", "class_arbor_1_1_group_node.html#aa182c9e607d1ca657b868fd8adfbda6aa24b09a0c424e7b75d63fdfe8d409a1f4", null ]
    ] ],
    [ "GroupNode", "class_arbor_1_1_group_node.html#a6b83a36af4ed3a976203cb3b0fa75c97", null ],
    [ "GetName", "class_arbor_1_1_group_node.html#aacc0d8210a719ab0b9dd1a4c085ba4a4", null ],
    [ "autoAlignment", "class_arbor_1_1_group_node.html#a32ca103f790bfde0a9fbfb987e1903d2", null ],
    [ "color", "class_arbor_1_1_group_node.html#aa5f4d1eda21c196bd8401ff73f105073", null ],
    [ "name", "class_arbor_1_1_group_node.html#a8ccf841cb59e451791bcb2e1ac4f1edc", null ]
];