var class_arbor_1_1_animator_bool_parameter_reference =
[
    [ "Get", "class_arbor_1_1_animator_bool_parameter_reference.html#af65bc920215ae690940100037f731cda", null ],
    [ "Set", "class_arbor_1_1_animator_bool_parameter_reference.html#abbe0803e94a0eb36d04d9bd17ecb96a0", null ]
];