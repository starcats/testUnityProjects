var class_arbor_1_1_internal_1_1_parameter_type_attribute =
[
    [ "ParameterTypeAttribute", "class_arbor_1_1_internal_1_1_parameter_type_attribute.html#aebf56ec1e99f9360a6a9be7687238d01", null ],
    [ "parameterType", "class_arbor_1_1_internal_1_1_parameter_type_attribute.html#a15821bb705ec574f93f1f41ba3b00ac1", null ]
];