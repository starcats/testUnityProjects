var class_arbor_1_1_object_pooling_1_1_pooling_item =
[
    [ "PoolingItem", "class_arbor_1_1_object_pooling_1_1_pooling_item.html#a1e5efa85fe44628646633b5bf3110b4e", null ],
    [ "PoolingItem", "class_arbor_1_1_object_pooling_1_1_pooling_item.html#aa7eedd3c4767f12467d981d73a7e6499", null ],
    [ "PoolingItem", "class_arbor_1_1_object_pooling_1_1_pooling_item.html#a6745514571bdc0189b2d5a99f3fedde6", null ],
    [ "amount", "class_arbor_1_1_object_pooling_1_1_pooling_item.html#a14236de313193a14b4dbdf442bcf2bb9", null ],
    [ "original", "class_arbor_1_1_object_pooling_1_1_pooling_item.html#ac31906cc49451afe07d9103aca023904", null ],
    [ "type", "class_arbor_1_1_object_pooling_1_1_pooling_item.html#ae2cd30c423a2fa173ac1808587066e51", null ]
];