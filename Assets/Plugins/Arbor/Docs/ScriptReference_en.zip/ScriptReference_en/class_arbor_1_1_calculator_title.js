var class_arbor_1_1_calculator_title =
[
    [ "CalculatorTitle", "class_arbor_1_1_calculator_title.html#a0b4133f00d5a5b6a27477cac5788b300", null ],
    [ "titleName", "class_arbor_1_1_calculator_title.html#ac09221fd89f11b856cd3d7ebc9abebce", null ]
];